<?php

session_start();
include_once "dbconfig.php";
if(verifyuser() || verifyuser_admin())
{
echo"<h1 align='center'>You Cannot View This Page</h1>";
echo"<h1 align='center'>Logout if logged in before <a href='logout.php'>click here</a></h1> ";
die();
}

?>

<!DOCTYPE html>
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
<!--<![endif]-->
	<head>
		<meta charset="utf-8">
		<title>Gurukula</title>
		<link rel="icon" href="images/favicon.phg" type="image/x-icon" />
		<meta name="description" content="Teaching Institute">
		<meta name="author" content="vikash mishra">

		<!-- Mobile Meta -->
		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<!-- Favicon 
		<link rel="shortcut icon" href="images/favicon.ico">-->

		<!-- Web Fonts -->
		<link href='http://fonts.googleapis.com/css?family=Open+Sans:400italic,700italic,400,700,300&amp;subset=latin,latin-ext' rel='stylesheet' type='text/css'>
		<link href='http://fonts.googleapis.com/css?family=Raleway:700,400,300' rel='stylesheet' type='text/css'>

		<!-- Bootstrap core CSS -->
		<link href="bootstrap/css/bootstrap.css" rel="stylesheet">

		<!-- Font Awesome CSS -->
		<link href="fonts/font-awesome/css/font-awesome.css" rel="stylesheet">

		<!-- Plugins -->
		<link href="css/animations.css" rel="stylesheet">

		<!-- Gurukula core CSS file -->
		<link href="css/style.css" rel="stylesheet">

		<!-- Custom css --> 
		<link href="css/custom.css" rel="stylesheet">
	</head>

	<body class="no-trans" style="background:URL('images/banner11.jpg')no-repeat fixed; background-size:cover;">
		<!-- scrollToTop -->
		<!-- ================ -->
		<div class="scrollToTop"><i class="icon-up-open-big"></i></div>

		<!-- header start -->
		<!-- ================ --> 
		<header class="header fixed clearfix  navbar navbar-fixed-top">
			<div class="container">
				<div class="row">
					<div class="col-md-4">

						<!-- header-left start -->
						<!-- ================ -->
						<div class="header-left clearfix">

							<!-- logo -->
							<div class="logo smooth-scroll">
								<a href="#banner"><img id="logo" src="images/logo.png" alt="Gurukula"></a>
							</div>

							

						</div>
						<!-- header-left end -->

					</div>
					<div class="col-md-8">

						<!-- header-right start -->
						<!-- ================ -->
						<div class="header-right clearfix">

							<!-- main-navigation start -->
							<!-- ================ -->
							<div class="main-navigation animated">

								<!-- navbar start -->
								<!-- ================ -->
								<nav class="navbar navbar-default" role="navigation">
									<div class="container-fluid">

										<!-- Toggle get grouped for better mobile display -->
										<div class="navbar-header">
											<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse-1">
												<span class="sr-only">Toggle navigation</span>
												<span class="icon-bar"></span>
												<span class="icon-bar"></span>
												<span class="icon-bar"></span>
											</button>
										</div>

										<!-- Collect the nav links, forms, and other content for toggling -->
										<div class="collapse navbar-collapse scrollspy smooth-scroll" id="navbar-collapse-1">
											<ul class="nav navbar-nav navbar-right">
												<li>
													<a  href="http://www.thegurukula.com">Gurukula Home</a>
												</li>
												<li>
													<a  href="http://www.blogs.thegurukula.com">Gurukula BLOGS</a>
												</li>
											</ul>
										</div>

									</div>
								</nav>
								<!-- navbar end -->

							</div>
							<!-- main-navigation end -->

						</div>
						<!-- header-right end -->

					</div>
				</div>
			</div>
		</header>
		<!-- header end -->








<div class="jumbotron container" style="background:transparent; padding-top:200px;">
			
				<div class="container">
    <div class="row">
        <div class="col-sm-4 ">
		
            <div class="panel panel-default">
                <div class="panel-heading">
                    <span class="glyphicon glyphicon-lock"></span>ADMIN Login</div>
                <div class="panel-body">
                    <form class="form-horizontal" role="form" method="POST">
                    <div class="form-group">
                        <label for="inputEmail3" class="col-sm-3 control-label">
                            User ID</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" id="inputEmail3" name="username" placeholder="User ID" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="inputPassword3" class="col-sm-3 control-label">
                            Password</label>
                        <div class="col-sm-9">
                            <input type="password" class="form-control" id="inputPassword3" name="password" placeholder="Password" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-offset-3 col-sm-9">
                            <div class="checkbox">
                                <label>
                                    <input type="checkbox"/>
                                    Remember me
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="form-group last">
                        <div class="col-sm-offset-3 col-sm-9">
                            <button type="submit" class="btn btn-success btn-sm" name="login" id="login">
                                Sign in</button>
                                 <button type="reset" class="btn btn-default btn-sm">
                                Reset</button>
                        </div>
                    </div>
                    </form>
                </div>
               
            </div>
        </div>
		
		
		
		
		<div class="col-sm-4 ">
		
            <div class="panel panel-default">
                <div class="panel-heading">
                    <span class="glyphicon glyphicon-lock"></span>Student Login</div>
                <div class="panel-body">
                    <form class="form-horizontal" role="form" method="POST">
                    <div class="form-group">
                        <label for="inputEmail3" class="col-sm-3 control-label">
                            User ID</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" id="inputEmail3" name="username" placeholder="User ID" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="inputPassword3" class="col-sm-3 control-label">
                            Password</label>
                        <div class="col-sm-9">
                            <input type="password" class="form-control" id="inputPassword3" name="password" placeholder="Password" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-offset-3 col-sm-9">
                            <div class="checkbox">
                                <label>
                                    <input type="checkbox"/>
                                    Remember me
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="form-group last">
                        <div class="col-sm-offset-3 col-sm-9">
                            <button type="submit" class="btn btn-success btn-sm" name="login1" id="login1">
                                Sign in</button>
                                 <button type="reset" class="btn btn-default btn-sm">
                                Reset</button>
                        </div>
                    </div>
                    </form>
                </div>
               
            </div>
        </div>
		
		
		<div class="col-sm-4 ">
		
            <div class="panel panel-default" >
			<div class="panel-heading">
                    <span class="glyphicon glyphicon-lock"></span>Free Stuffs</div>
               <p align="center"> Not a Member...<br/>
				We still have stuffs for you...</p>
				<p align="center"><a href="free.php" class="btn btn-success btn-sm" > Move In</a></p>
            </div>
        </div>
		
		
		
		
		
		
    </div>
</div>

			
			</div>
			
			<?php

include_once"dbconfig.php";
if(isset($_POST['login']))
{
	$username=$_POST['username'];
	$password=$_POST['password'];
	if(isset($_POST['rem']))
		$rem='yes';
	else
		$rem='no';
	$query="select count(*) from admin_login where username='$username' and password='$password'";
	$n=my_one($query);
if($n!=1)
	{
		//echo"Error in login";
	echo("<script> location.href='login_error.php'</script>");
	}
	else
	{
	$_SESSION['sun']=$username;
	$_SESSION['spwd']=$password;
		if($rem=='yes')
			{
			setcookie('cun',$username,time()+60*60*24*7);
			setcookie('cpwd',$password,time()+60*60*24*7);
			}
echo("<script> location.href='admin_db.php'</script>");
	}
}else if(isset($_POST['login1']))
{
	$username=$_POST['username'];
	$password=$_POST['password'];
	if(isset($_POST['rem']))
		$rem='yes';
	else
		$rem='no';
	$query="select count(*) from student_login where username='$username' and password='$password'";
	$n=my_one($query);
if($n!=1)
	{
		//echo"Error in login";
	echo("<script> location.href='login_error.php'</script>");
	}
	else
	{
	$_SESSION['sun']=$username;
	$_SESSION['spwd']=$password;
		if($rem=='yes')
			{
			setcookie('cun',$username,time()+60*60*24*7);
			setcookie('cpwd',$password,time()+60*60*24*7);
			}
echo("<script> location.href='student_db.php'</script>");
	}
}
	



?>	

<!-- JavaScript files placed at the end of the document so the pages load faster
		================================================== -->
		<!-- Jquery and Bootstap core js files -->
		<script type="text/javascript" src="plugins/jquery.min.js"></script>
		<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>

		<!-- Modernizr javascript -->
		<script type="text/javascript" src="plugins/modernizr.js"></script>

		<!-- Isotope javascript -->
		<script type="text/javascript" src="plugins/isotope/isotope.pkgd.min.js"></script>
		
		<!-- Backstretch javascript -->
		<script type="text/javascript" src="plugins/jquery.backstretch.min.js"></script>

		<!-- Appear javascript -->
		<script type="text/javascript" src="plugins/jquery.appear.js"></script>

		<!-- Initialization of Plugins -->
		<script type="text/javascript" src="js/template.js"></script>

		<!-- Custom Scripts -->
		<script type="text/javascript" src="js/custom.js"></script>
		
</body>
</html>
			