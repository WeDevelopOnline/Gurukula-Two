$(document).ready(function(){
				$("#callBtn").click(function(){
				$("#call").fadeOut(300),
				$("#drag").fadeIn(2500)
				});
			});
		